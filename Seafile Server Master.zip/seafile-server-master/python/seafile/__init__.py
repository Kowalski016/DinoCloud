from .rpcclient import SeafServerThreadedRpcClient as ServerThreadedRpcClient

class TaskType(object):
    DOWNLOAD = 0
    UPLOAD = 1
