go run test_upload.go -c accont.conf -p runtime
