import pytest
from seaserv import seafile_api as api

def test_server_config():

    #test_set_server_config_int and get_server_config_int
    t_group = 't_group'
    t_key = 't_key'
    t_value = 1
    api.set_server_config_int(t_group, t_key, t_value)
    t_ret = api.get_server_config_int(t_group, t_key)
    assert t_ret == t_value

    #test_set_server_config_int64 and get_server_config_int64
    t_group = 't_group'
    t_key = 't_key'
    t_value = 9223372036854775807
    api.set_server_config_int64(t_group, t_key, t_value)
    t_ret = api.get_server_config_int64(t_group, t_key)
    assert t_ret == t_value

    #test_set_server_config_string and get_server_config_string
    t_group = 't_group'
    t_key = 't_key'
    t_value = 't_value'
    api.set_server_config_string(t_group, t_key, t_value)
    t_ret = api.get_server_config_string(t_group, t_key)
    assert t_ret == t_value

    #test_set_server_config_boolean and get_server_config_boolean
    t_group = 't_group'
    t_key = 't_key'
    t_value = True
    api.set_server_config_boolean(t_group, t_key, t_value)
    t_ret = api.get_server_config_boolean(t_group, t_key)
    assert t_ret == t_value

    t_value = False
    api.set_server_config_boolean(t_group, t_key, t_value)
    t_ret = api.get_server_config_boolean(t_group, t_key)
    assert t_ret == t_value
