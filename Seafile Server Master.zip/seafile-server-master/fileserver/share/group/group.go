// Package group manages group membership and group shares.
package group
